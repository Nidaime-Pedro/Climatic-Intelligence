import requests
import pycountry
from deep_translator import GoogleTranslator
import os

# Configuração dos headers
HEADERS = {'Content-Type': 'application/json'}

# Chave da API do WeatherAPI (Use variável de ambiente para segurança)
API_KEY = os.getenv("WEATHER_API_KEY", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXX")


def req_clima(city):
    """ Obtém os dados do clima para a cidade fornecida. """
    try:
        url = f"http://api.weatherapi.com/v1/current.json?key={API_KEY}&q={city}"
        response = requests.get(url, headers=HEADERS)
        data = response.json()

        if "error" in data:
            return {"error": "Cidade não encontrada ou erro na API"}

        return data
    except Exception as e:
        return {"error": f"Erro ao obter o clima: {str(e)}"}


def get_country_code(country_name):
    """ Obtém o código do país usando a API RestCountries. """
    try:
        response = requests.get(f"https://restcountries.com/v3.1/name/{country_name}?fullText=true")
        data = response.json()
        return data[0]["cca2"].lower() if data else None
    except:
        return None


def get_lang(country_code):
    """ Obtém o idioma oficial do país. """
    try:
        response = requests.get(f"https://restcountries.com/v3.1/alpha/{country_code}")
        data = response.json()
        return list(data[0].get("languages", {}).values()) if data else ["en"]
    except:
        return ["en"]


def traduzir_texto(texto, idioma_destino="en"):
    """ Traduz o texto para o idioma desejado. """
    try:
        tradutor = GoogleTranslator(source="en", target=idioma_destino)
        return tradutor.translate(texto)
    except Exception as e:
        return f"Erro na tradução: {str(e)}"


def obter_clima_traduzido(cidade, lang="0"):
    """ Obtém e traduz as informações do clima da cidade fornecida. """
    dados_clima = req_clima(cidade)

    if "error" in dados_clima:
        return dados_clima["error"]

    country = dados_clima["location"]["country"]
    country_code = get_country_code(country)
    linguas_oficiais = get_lang(country_code)

    # Determinar idioma final
    if lang == "1":
        lingua_destino = pycountry.languages.get(name=linguas_oficiais[0])
        lingua_destino = lingua_destino.alpha_2 if lingua_destino and hasattr(lingua_destino, 'alpha_2') else "en"
    else:
        lingua_destino = "en"

    clima_texto = f"Weather in {dados_clima['location']['name']}, {country}: {dados_clima['current']['condition']['text']}, {dados_clima['current']['temp_c']}°C."
    clima_traduzido = traduzir_texto(clima_texto, lingua_destino)

    return clima_traduzido