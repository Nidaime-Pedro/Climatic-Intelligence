#from climatic_intelligence import server
#from flask import jsonify, make_response
#from climatic_intelligence.climatic import obter_clima_traduzido

#@server.route('/')
#def homepage():
#    return make_response(
#    jsonify({"message": "Bem vindo a home!"})
#    )
#    
#@server.route('/get/<city>', methods=['GET'])
#def clima(city):
#    try:
#        response = obter_clima_traduzido(city)
#        return make_response(
#            jsonify( {"returned": response})
#        )
#        
#    except Exception as e:
#        return make_response(
#        jsonify({
#        "message": str(e)
#        })
#        )

from climatic_intelligence import server
from flask import jsonify, make_response, request
from climatic_intelligence.climatic import obter_clima_traduzido

@server.route('/')
def homepage():
    return make_response(
        jsonify({"message": "Bem-vindo à API de Clima!"}),
        200
    )

@server.route('/get/<city>', methods=['GET'])
def clima(city):
    try:
        lang = request.args.get('lang', '0')  # Captura ?lang=1 ou usa padrão '0'
        response = obter_clima_traduzido(city, lang)
        
        return make_response(
            jsonify({"returned": response}),
            200
        )

    except Exception as e:
        return make_response(
            jsonify({"error": "Erro ao buscar clima", "details": str(e)}),
            500
        )