from flask import Flask

server = Flask('__main__')


from climatic_intelligence.routes import homepage
from climatic_intelligence.routes import clima