from climatic_intelligence import server
from flask_cors import CORS
CORS(server)
if __name__ == '__main__':
    server.run(debug=True)
